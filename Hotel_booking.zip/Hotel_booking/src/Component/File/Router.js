import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Home } from "../Pages/Home"
import Book from '../Pages/Book';
import Contact from "../Pages/Contact"

export default function Router() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
            <Route exact path='/' element={<Home/>}> </Route>
            <Route exact path="/bookanappointment" element={<Book/>}></Route>

            <Route exact path="/contact" element={<Contact/>}></Route>

        </Routes>
        
      </BrowserRouter>
    </div>
  );
}
